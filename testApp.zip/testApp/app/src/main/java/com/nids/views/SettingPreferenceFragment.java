package com.nids.views;

import android.content.SharedPreferences;
import android.os.Bundle;
//import android.support.annotation.Nullable;
import android.widget.BaseAdapter;

import androidx.annotation.Nullable;
import androidx.preference.ListPreference;
import androidx.preference.PreferenceFragment;
import androidx.preference.PreferenceManager;
import androidx.preference.PreferenceScreen;

import com.nids.kind4u.testapp.R;

public class SettingPreferenceFragment extends PreferenceFragment {

    SharedPreferences prefs;

    PreferenceScreen editUserPreference;
    PreferenceScreen registCarPreference;
    PreferenceScreen editCarPreference;
    ListPreference soundPreference;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        addPreferencesFromResource(R.xml.settings_preference);
        soundPreference = (ListPreference)findPreference("sound_list");
        editUserPreference = (PreferenceScreen) findPreference("edit_user");
        registCarPreference = (PreferenceScreen) findPreference("regist_car");
        editCarPreference = (PreferenceScreen) findPreference("edit_car");

        prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());

        if(!prefs.getString("sound_list", "").equals("")){
            soundPreference.setSummary(prefs.getString("sound_list", "5분"));
        }

        prefs.registerOnSharedPreferenceChangeListener(prefListener);
    }
    SharedPreferences.OnSharedPreferenceChangeListener prefListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
            if(key.equals("sound_list")){
                soundPreference.setSummary(prefs.getString("sound_list", "5분"));
            }
        }
    };

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {

    }
}
